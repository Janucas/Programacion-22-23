'''
Created on 11 nov 2022

@author: Juanan
'''
# def obtenerFechaFormatoLargo():
#     mensaje=""
#     dia=int(input("Introduce un dia"))
#     lista=[0,"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]
#     while dia>0:
#         mes=int(input("Introduzca el mes que desee"))
#         while mes<0 and mes>12 :
#             mes=int(input("Dtos incorrectos.Introduzca el mes que desee (mayor que 0 y menor que 12"))
#
#         anio=int(input("Introduzca el año que desee"))
#         while anio<0 and anio>2022:
#             anio=int(input("Datos incorrectos. Introduzca el año que desee (mayor que 0 y menor que 2022"))
#         mensaje=(f"La fecha se trata del {dia} de {lista[mes]} del {anio}")
#
#         dia=int(input("Introduzca el dia que desee"))
#
#     return mensaje
#
# print (obtenerFechaFormatoLargo())
#Comprobar fallos de vañidacion en mi solucion

#-----------------------------------------------------------------------------------------
#SOLUCION JOSE(profe)
#-----------------------------------------------------------------------------------------
#Rehacer ejercicio jose mirandolo en la moodle, primero comprender y luego hacer sin mirar















